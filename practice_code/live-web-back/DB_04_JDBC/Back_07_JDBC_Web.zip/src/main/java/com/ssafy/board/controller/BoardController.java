package com.ssafy.board.controller;

import java.io.IOException;
import java.util.List;

import com.ssafy.board.model.dto.Board;
import com.ssafy.board.model.service.BoardService;
import com.ssafy.board.model.service.BoardServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/board")
public class BoardController extends HttpServlet {

	private BoardService service = BoardServiceImpl.getInstance();

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String act = request.getParameter("act");

		switch (act) {
		case "writeform":
			doWriteForm(request, response);
			break;
		case "write":
			doWrite(request, response);
			break;
		case "list":
			doList(request, response);
			break;
		case "detail":
			doDetail(request, response);
			break;
		case "delete":
			doRemove(request, response);
			break;
		case "updateform":
			doUpdateForm(request, response);
			break;
		case "update":
			doUpdate(request, response);
			break;
		}

	}

	private void doUpdate(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Board board = service.getBoard(Integer.parseInt(request.getParameter("id")));
		board.setTitle(request.getParameter("title"));
		board.setContent(request.getParameter("content"));

		service.modifyBoard(board);

		response.sendRedirect("board?act=list");
	}

	private void doUpdateForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));

		Board board = service.getBoard(id);
		request.setAttribute("board", board);
		request.getRequestDispatcher("/WEB-INF/board/updateform.jsp").forward(request, response);
	}

	private void doRemove(HttpServletRequest request, HttpServletResponse response) throws IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		service.removeBoard(id);
		response.sendRedirect("board?act=list");
	}

	private void doDetail(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));

		request.setAttribute("board", service.getBoard(id));
		request.getRequestDispatcher("/WEB-INF/board/detail.jsp").forward(request, response);
	}

	private void doList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 전체 조회 -> 서비스 호출 -> 레포지토리 호출 -> 메모리에서 꺼내와서 -> 서비스 -> 컨트롤러
		List<Board> list = service.getList();
		request.setAttribute("list", list); // 속성으로 통로에 담아서 보낸다~!
		// list.jsp 를 보여줘야해~~
		request.getRequestDispatcher("/WEB-INF/board/list.jsp").forward(request, response);

	}

	private void doWrite(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String title = request.getParameter("title");
		String writer = request.getParameter("writer");
		String content = request.getParameter("content");

		// 게시글 객체를 생성하자
		Board board = new Board(title, writer, content);

		// 등록하자! -> 서비스 호출 -> 레포지토리 호출 -> 메모리저장 -> 레포 -> 서비스 -> 컨트롤러
		service.writeBoard(board);

		// 등록을 확인하던지, 메인으로 튕기던지
		// 1. 메인 튕기기 -> index.jsp 리다이렉트

		// 2. 조회 -> 리다이렉트
		// 2-1. 전체 조회
		response.sendRedirect("board?act=list");
		// 2-2. 상세 조회
//		response.sendRedirect("board?act=detail?id=게시글id");
	}

	private void doWriteForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 작성페이지 주세용~~~ -> 포워딩
		request.getRequestDispatcher("/WEB-INF/board/writeform.jsp").forward(request, response);
	}

}
