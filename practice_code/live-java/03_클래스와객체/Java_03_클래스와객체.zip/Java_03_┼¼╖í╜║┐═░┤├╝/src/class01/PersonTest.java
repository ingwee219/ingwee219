package class01;

public class PersonTest {
	public static void main(String[] args) {
		// 사람의 정보를 관리하자!

		String name1 = "Yang";
		int age1 = 45;
		String hobby1 = "Youtube";

		String name2 = "Hong";
		int age2 = 25;
		String hobby2 = "Golf";

		// 사람이 100명이라면.... 너무 힘들다!

		// 배열!(서울 17반 박지우 명예)
		int size = 100;
		String[] names = new String[size];
		int[] ages = new int[size];
		String[] hobbies = new String[size];

		names[0] = "Yang";
		names[1] = "Hong";
		ages[0] = 45;
		ages[1] = 25;
		hobbies[0] = "Youtube";
		hobbies[1] = "Golf";
		
		

	}
}
