package class03;

public class PersonTest {
	public static void main(String[] args) {
		//Yang을 생성해보자!
		//클래스이름 변수이름 = new 클래스이름();
		Person yang = new Person();
		
		yang.name = "Yang";
		yang.age = 45;
		yang.hobby = "Youtube";
		
		Person hong = new Person();
		hong.name = "Hong";
//		hong.age = 25;
//		hong.hobby = "Golf";
		
//		yang.info();
//		hong.info();
		
		//아래에 작성된 100을 인자
		yang.study(100);
		
		short s = 20;
		long l = 1000;
		yang.study(l);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
