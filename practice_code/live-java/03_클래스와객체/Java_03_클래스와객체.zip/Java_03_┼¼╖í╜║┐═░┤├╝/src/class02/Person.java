package class02;

public class Person {
	String name;
	int age;
	String hobby;
	
}
