package inheritance04_overriding;

public class Test {
	public static void main(String[] args) {
//		@SuppressWarnings("unused")
		Student st = new Student();
		
		st.eat();
		st.eat(1);
		Person p = new Person();
		System.out.println(p);
		
		
		
	}
}
