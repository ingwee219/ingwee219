package inheritance03_super;

public class Test {
	public static void main(String[] args) {
//		@SuppressWarnings("unused")
		Student st = new Student();
		
//		st.eat();
		
	}
}
