package inheritance03_super;

//Person 상속받기 위해서 extends 키워드를 사용하겠다.
public class Student extends Person {
	String major;

	public void study() {
		System.out.println("공부를 한다.");
	}

	public Student() {
		//주석?
		super("익명", 10); //생략이 되어있다! ->	부모의 기본생성자를 호출
//		this("익명", 0, "자유전공");
	}

	public Student(String name, int age, String major) {
		super(name, age);
		this.major = major;
	}

}
