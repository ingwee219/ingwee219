package inheritance01_no;

public class Person {
	String name;
	int age;
	
	public void eat() {
		System.out.println("음식을 먹는다.");
	}
}
