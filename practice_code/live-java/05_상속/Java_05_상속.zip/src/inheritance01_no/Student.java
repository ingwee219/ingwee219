package inheritance01_no;

public class Student {
	String name;
	int age;
	String major;
	
	public void eat() {
		System.out.println("음식을 먹는다.");
	}
	
	public void study() {
		System.out.println("공부를 한다.");
	}
}
