package inheritance02_ok;

//패키지 구조가 다르기때문에 이거 가능~~
public class Object {

}
