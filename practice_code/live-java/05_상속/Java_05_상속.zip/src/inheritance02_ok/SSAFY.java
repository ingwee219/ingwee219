package inheritance02_ok;

public class SSAFY extends Student {

}
