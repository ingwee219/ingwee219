package inheritance02_ok;

public class Person {
	String name;
	private int age;
	
	public void eat() {
		System.out.println("음식을 냠냠 먹는다.");
	}
}
