package inheritance05_final;

public class Test {
	public static void main(String[] args) {
		
		final String[] arr = new String[10];
		
		final int[][] arr2 = {{},{},{}};
		
		arr[0] = "Yang";
		arr[1] = "Yoon";
		arr[2] = "Kim";
		
//		arr = new String[100]; //이런게 안된다!
		
		
	}
}
