//package inheritance05_final;
//
////Person 상속받기 위해서 extends 키워드를 사용하겠다.
//public class Student extends Person {
//	String major;
//
//	//오버라이딩 했다 -> 강제성이 부여가 됩니다.!
//	//부모클래스에 정의된 메서드와 동일해야함
//	//메서드 이름/매개변수/반환타입
//	//접근제한자는 부모보다 넓어야 된다.
////	@Override
////	public void eat() {
////		System.out.println("지식을 먹는다. ");
////	}
////	
//	
//	//메서드 오버로딩
//	//메서드명 동일해야하고, 매개변수 순선, 개수가 다른것
//	//반환타입만 다른건 노인정
//	public void eat(int time) {
//		System.out.println(time + "시간 만큼 지식을 먹는다. ");
//	}
//	
//	public void study() {
//		System.out.println("공부를 한다.");
//	}
//
//	public Student() {
//		//주석?
//		super("익명", 10); //생략이 되어있다! ->	부모의 기본생성자를 호출
////		this("익명", 0, "자유전공");
//	}
//
//	public Student(String name, int age, String major) {
//		super(name, age);
//		this.major = major;
//	}
//
//
//	@Override
//	public String toString() {
//		return "Student [major=" + major + "]";
//	}
//
//	
//}
