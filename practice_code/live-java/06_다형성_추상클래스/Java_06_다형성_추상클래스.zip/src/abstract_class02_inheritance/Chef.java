package abstract_class02_inheritance;

public class Chef {
	String name;
	int age;
	
	public void eat() {
		System.out.println("음식을 먹는다.");
	}
	
	
	//사용이 되지 않을거 같다! -> 슬픈일! -> 지우자!
//	public void cook() {
//		System.out.println("음식을 조리한다.");
//	}
}
