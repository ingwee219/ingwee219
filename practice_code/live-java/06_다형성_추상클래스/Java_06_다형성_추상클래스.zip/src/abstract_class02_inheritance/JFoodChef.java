package abstract_class02_inheritance;

public class JFoodChef extends Chef{
	String speciality; //내주전공
	
//	@Override
	public void cook() {
		System.out.println("일식을 조리한다.");
	}
}
