package abstract_class03;

public class JFoodChef extends Chef{
	String speciality; //내주전공
	
	@Override
	public void eat() {
		System.out.println("일식을 먹는다.");
	}
	
	@Override
	public void cook() {
		System.out.println("일식을 조리한다.");
	}
}
