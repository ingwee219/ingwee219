package abstract_class03;


//추상 메서드가 없다고 하더라도 추상 클래스가 될 수 있음!
public abstract class CFoodChef extends Chef {
	//추상클래스를 상속 받는 경우! 
	//2가지 선택권이 있다!
	//1. 추상메서드를 구현할 것!
	//2. 구현하기 싫으면 나도 추상클래스가 될것!
}
