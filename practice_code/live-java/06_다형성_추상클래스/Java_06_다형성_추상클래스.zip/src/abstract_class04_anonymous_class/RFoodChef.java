package abstract_class04_anonymous_class;

public class RFoodChef extends Chef{

	@Override
	public void cook() {
		System.out.println("랜덤 요리 가능!");
	}

}
