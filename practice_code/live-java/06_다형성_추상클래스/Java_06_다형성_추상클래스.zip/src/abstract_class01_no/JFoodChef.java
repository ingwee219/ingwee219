package abstract_class01_no;

public class JFoodChef {
	String name;
	int age;
	String speciality; //내주전공
	
	public void eat() {
		System.out.println("음식을 먹는다.");
	}
	
	public void cook() {
		System.out.println("일식을 조리한다.");
	}
}
