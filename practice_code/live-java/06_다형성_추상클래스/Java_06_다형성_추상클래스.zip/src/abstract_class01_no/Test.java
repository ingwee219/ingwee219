package abstract_class01_no;

public class Test {
	public static void main(String[] args) {
		KFoodChef k = new KFoodChef();
		JFoodChef j = new JFoodChef();
		
		k.cook();
		j.cook();
	}
}
