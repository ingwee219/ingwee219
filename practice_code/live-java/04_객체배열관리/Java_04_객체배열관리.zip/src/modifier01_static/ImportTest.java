package modifier01_static;

import java.util.Arrays;
import java.util.LinkedList;

import java.util.*;
import static java.lang.Math.PI;

public class ImportTest {
	public static void main(String[] args) {
		
//		System.out.println(Arrays.toString(null));
//		LinkedList<E>
		
		System.out.println(Math.PI);
		System.out.println(PI);
	}
}
