package modifier05_public;

//public : 오픈
public class Person {
	public String name;
	public int age;

	public void info() {
		this.name = "Yang"; // 나는 내부이니까 접근이 가능하다.
	}
}
