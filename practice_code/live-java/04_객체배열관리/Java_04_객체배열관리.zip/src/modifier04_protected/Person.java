package modifier04_protected;

//protected : 같은 패키지 안에서 접근이 가능 / 다른패키지는 상속 관계
public class Person {
	protected String name;
	protected int age;
	
	
	protected void info() {
		this.name = "Yang"; //나는 내부이니까 접근이 가능하다.
	}
}
