package modifier07_object_array;

public class PersonManager {

	private Person[] arr = new Person[100];

	//접근자
	public Person[] getArr() {
		return arr;
	}

	// 메서드
	// 추가
	// 수정
	// 삭제
	// 조회

}
