package modifier07_object_array;

public class PersonTest {
	public static void main(String[] args) {
		
		PersonManager mgr = new PersonManager();
		//사람추가 / 추가 
		
		
		PersonManager mgr2 = new PersonManager();
		//목록 가져와!
	
	}
}
