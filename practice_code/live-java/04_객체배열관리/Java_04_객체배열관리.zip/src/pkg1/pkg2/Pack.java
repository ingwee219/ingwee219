package pkg1.pkg2;

class Test {
	
}

class Test2 {
	
}
public class Pack {
	public String pkg = "pkg1.pkg2";
}
