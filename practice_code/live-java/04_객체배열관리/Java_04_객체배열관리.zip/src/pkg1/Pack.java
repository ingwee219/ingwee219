package pkg1;

public class Pack {
	public String pkg = "pkg1";
}
