package modifier03_default;

//default : 같은 패키지 안에서 접근이 가능
public class Person {
	String name;
	int age;
	
	
	void info() {
		this.name = "Yang"; //나는 내부이니까 접근이 가능하다.
	}
}
