package modifier02_private;

public class PersonTest {
	public static void main(String[] args) {
		Person p = new Person();
		
//		p.age = 100; //private 이라서 다른 클래스에서는 접근할 수 없다!
//		p.info();
	}
}
