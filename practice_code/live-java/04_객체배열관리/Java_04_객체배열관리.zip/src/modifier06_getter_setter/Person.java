package modifier06_getter_setter;

public class Person {
	//외부에서 접근이 불가능하다!
	private String name;
	private int age;
	private String myName;
	
	public Person() {
		// TODO Auto-generated constructor stub
	}
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	//나이를 수정하기 위해서는 어떻게? 메서드를 구현한다.
	//메서드의 이름을 하고싶은데로 해도 상관은 없음! 
	//관례가 존재
	//설정자(메서드) set(필드명 첫글자는 대문자로)
	public void setAge(int age) {
		//무수히 많은 코드를 실행 시킬수 있다!
		if(age < 0 ) {
			System.out.println("나이는 음수가 되서는 안된다!");
		} else if(age >= 150) {
			System.out.println("뱀파이어 입니까?");
		}else {
			this.age = age;
		}
		
	}
	
	//접근자 get(필드명 첫글자는 대문자로)
	public int getAge() {
		return age;
	}
	
	public String getMyName() {
		return myName;
	}
	
	
	
	
	
	
	
	
	
	
	public void info() {
		System.out.println(name+":"+age);
	}

}
