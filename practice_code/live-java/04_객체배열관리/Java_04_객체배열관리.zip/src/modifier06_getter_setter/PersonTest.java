package modifier06_getter_setter;

public class PersonTest {
	public static void main(String[] args) {
		Person p = new Person("김싸피", 20);
	
//		p.age = 100;
		p.setAge(100);
		
		p.info();
		
			
	}
}
