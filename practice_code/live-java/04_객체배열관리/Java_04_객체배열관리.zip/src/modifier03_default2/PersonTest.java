package modifier03_default2;

import modifier03_default.Person;

public class PersonTest {
	public static void main(String[] args) {
		Person p = new Person();
		
//		p.age = 100; //default 다른 패키지 접근 불가능!
//		p.info();
	}
}
