package generics02_generics_box;

//타입을 결정한 박스
class Box<T> {
	private T obj;

	public T getObj() {
		return obj;
	}

	public void setObj(T obj) {
		this.obj = obj;
	}
}

public class BoxTest {
	public static void main(String[] args) {
//		Box box1 = new Box(); //Object -> Raw (비권장)
//		Box<Object> box2 = new Box<Object>();

		Box<String> stringBox = new Box<>(); // 생성자 쪽 꺾쇠 안은 생략해도 됨!
//		Box<> stringBox = new Box<String>(); //선언 쪽 꺾쇠 안은 생략하면 안됨!

		stringBox.setObj("안녕하세요!");
		stringBox.getObj();

		///////////////////////////////////////////////
		// 정수형을 넣고 싶어!
		// 기초자료형은 넣을 수 없어!
//		Box<int> intBox = new Box<>();
		// 참조자료형을 넣어야 해!
		Box<Integer> intBox = new Box<>();

		// 기초자료형 -> 참조자료형 Wrapper 클래스
		// int -> Integer
		// char -> Character
		// boolean -> Boolean
		// double -> Double
		// ....

		int i1 = 11; // 객체 X
		Integer i2 = 11; // 객체 O : AutoBoxing

		Integer i3 = Integer.valueOf(11); // 객체O -> Boxing

		int i4 = i3; // 객체 X : AutoUnboxing
		int i5 = i3.intValue(); // 객체 X : Unboxing

	}

}
