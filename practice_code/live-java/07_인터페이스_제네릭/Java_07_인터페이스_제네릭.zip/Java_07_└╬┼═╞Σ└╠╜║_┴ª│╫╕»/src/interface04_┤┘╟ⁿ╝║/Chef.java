package interface04_다형성;

public interface Chef {
	void cook();
}
