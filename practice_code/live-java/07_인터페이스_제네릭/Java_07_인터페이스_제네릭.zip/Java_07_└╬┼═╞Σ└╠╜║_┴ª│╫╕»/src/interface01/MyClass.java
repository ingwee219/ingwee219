package interface01;

public class MyClass implements MyInterface {

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		
	}

	public void method2() {
		// TODO Auto-generated method stub
		
	}

}
