package interface02_다중;

//다중 상속을 처리하겠다!
public interface Bird extends Swimmable, Flyable{
	void eat();
}
