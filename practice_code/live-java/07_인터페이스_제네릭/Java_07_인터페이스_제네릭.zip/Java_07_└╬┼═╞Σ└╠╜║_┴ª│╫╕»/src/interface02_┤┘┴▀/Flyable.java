package interface02_다중;

public interface Flyable {
	void fly(); //제한자 생략되어 있음!
}
