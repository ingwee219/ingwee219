package interface02_다중;

public interface Swimmable {
	void swim(); //제한자 생략되어 있음!
}
