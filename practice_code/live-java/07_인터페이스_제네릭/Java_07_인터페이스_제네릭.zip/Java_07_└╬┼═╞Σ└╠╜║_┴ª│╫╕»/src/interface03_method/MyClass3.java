package interface03_method;

public class MyClass3 extends MyClass1 implements MyInterface2{

}
