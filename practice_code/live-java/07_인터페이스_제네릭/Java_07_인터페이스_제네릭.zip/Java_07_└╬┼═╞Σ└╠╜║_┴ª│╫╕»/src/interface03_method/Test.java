package interface03_method;

public class Test {
	public static void main(String[] args) {
//		MyInterface1 i = new MyInterface1();
		MyClass1 c = new MyClass1();
		
//		c.method2();
		
		MyClass3 c3 = new MyClass3();
		c3.method3();

		MyInterface2.method4();
	}
}
