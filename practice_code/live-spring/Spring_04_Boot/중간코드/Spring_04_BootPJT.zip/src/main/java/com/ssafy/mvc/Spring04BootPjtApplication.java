package com.ssafy.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring04BootPjtApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring04BootPjtApplication.class, args);
	}

}
