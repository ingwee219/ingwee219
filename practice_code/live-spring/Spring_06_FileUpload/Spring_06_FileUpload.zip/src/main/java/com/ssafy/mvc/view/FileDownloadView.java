package com.ssafy.mvc.view;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.Map;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.view.AbstractView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class FileDownloadView extends AbstractView{

	private ResourceLoader loader;

	//생성자 주입(생성자가 1개뿐이라면 Autowried 생략 가능)
//	@Autowired
	public FileDownloadView(ResourceLoader loader) {
		this.loader = loader;
	}
	
	@Override
	protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		//이미지의 식별자를 넘겼어야 하는데 컨트롤러에서 이름을 넣어서 보냈다.
		String fileName = (String)model.get("fileName");
		//이미지가 어디에 있는데? static/img
		Resource resource = loader.getResource("classpath:/static/img");
		File file = new File(resource.getFile(), fileName);
		///////////////////////////////////////////////////////////
		fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");//한글꺠짐 방지
		response.setHeader("Content-Disposition", "attachment; fileName=\""+fileName+"\";");
		response.setHeader("Content-Transfer-Encoding", "binary");
		/////////////////////////////////////////////////////////////
		//파일을 다운로드 하자
		try(FileInputStream fis = new FileInputStream(file);
				OutputStream os = response.getOutputStream();){
			FileCopyUtils.copy(fis, os);
		}
		
		
		
		
		
		
		
		
		
		
	}

}
