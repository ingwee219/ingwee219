package com.ssafy.proxy02;

public interface Person {
	void coding();
}
