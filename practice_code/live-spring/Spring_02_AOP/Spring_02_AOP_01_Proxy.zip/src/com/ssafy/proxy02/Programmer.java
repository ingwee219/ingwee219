package com.ssafy.proxy02;

import java.util.Random;

public class Programmer implements Person {
	// 필드는 생략!

	// 주된 일상
	public void coding() {
		System.out.println("열심히 코드를 작성한다."); // 핵심기능
	}
}
