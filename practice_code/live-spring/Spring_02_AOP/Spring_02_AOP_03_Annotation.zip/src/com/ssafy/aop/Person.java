package com.ssafy.aop;

public interface Person {
	Integer coding() throws OuchException;
}
