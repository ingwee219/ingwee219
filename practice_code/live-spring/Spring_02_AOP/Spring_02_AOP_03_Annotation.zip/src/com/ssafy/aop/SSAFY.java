//package com.ssafy.aop;
//
//import java.util.Random;
//
//public class SSAFY implements Person {
//	// 필드는 생략!
//
//	// 주된 일상
//	public void coding() {
//		System.out.println("열심히 공부를 한다."); // 핵심기능
//	}
//}
