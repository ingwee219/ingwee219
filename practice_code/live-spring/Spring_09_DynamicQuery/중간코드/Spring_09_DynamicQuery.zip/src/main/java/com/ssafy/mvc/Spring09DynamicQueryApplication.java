package com.ssafy.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Spring09DynamicQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring09DynamicQueryApplication.class, args);
	}

}
