package com.ssafy.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring11RestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring11RestapiApplication.class, args);
	}

}
