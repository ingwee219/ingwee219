package com.ssafy.mvc.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.ssafy.mvc.interceptor.AInterceptor;
import com.ssafy.mvc.interceptor.BInterceptor;
import com.ssafy.mvc.interceptor.CInterceptor;
import com.ssafy.mvc.interceptor.LoginCheckInterceptor;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final FilterConfig filterConfig;
	
	//인터셉터들을 빈으로 등록해둔 상태!
	@Autowired
	private AInterceptor aInterceptor;
	@Autowired
	private BInterceptor bInterceptor;
	@Autowired
	private CInterceptor cInterceptor;
	@Autowired
	private LoginCheckInterceptor checkInterceptor;


    WebConfig(FilterConfig filterConfig) {
        this.filterConfig = filterConfig;
    }
	
	
	//대전3 이서연 -> 깊콘
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		//인터셉터를 추가를 하즈아~~
//		registry.addInterceptor(aInterceptor).addPathPatterns("/hello");
//		registry.addInterceptor(bInterceptor).addPathPatterns("/hello");
//		registry.addInterceptor(cInterceptor).addPathPatterns("/hello");
		registry.addInterceptor(checkInterceptor).addPathPatterns("/**").excludePathPatterns("/login");
	}
}
