package com.ssafy.mvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.mvc.model.dto.User;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	
	@GetMapping("/hello")
	public String hello() {
		return "hello";
	}
	
	@GetMapping("/login")
	public String loginForm() {
		return "/user/loginForm"; //WEB-INF/views/user/loginForm.jsp
	}
	
	@PostMapping("/login")
	public String login(@ModelAttribute User user, HttpSession session) {
		//User라고 하는 객체를 하나 만들어서 관리하면 아주 EZ하게 철기가 되겠어!
		//넘겨받은 User를 이용해서 실제로 우리의 회원인지를 쳌 -> Service 호출 -> DAO 호출 -> DB
		
		//지금 로그인이 되었다! 검증 끝이라고 가정
		//세션에 저장을 하겠다!
		session.setAttribute("loginUser", user.getId());
		return "redirect:hello";
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		//로그아웃을 하는 방법 2가지 중 한개만 하면 가능
		//1. 속성 지우기 (로그인 정보)
		session.removeAttribute("loginUser");
		//2. 세션 초기화
		session.invalidate();
		
		return "redirect:hello";
	}
	
	
	
	
	
	
	
	
	
	
}
