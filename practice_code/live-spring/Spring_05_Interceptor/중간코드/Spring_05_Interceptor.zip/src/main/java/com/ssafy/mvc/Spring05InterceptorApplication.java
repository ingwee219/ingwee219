package com.ssafy.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring05InterceptorApplication {

	public static void main(String[] args) {
		 SpringApplication.run(Spring05InterceptorApplication.class, args);
	}

}
